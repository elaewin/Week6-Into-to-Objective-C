//
//  ViewController.m
//  MultiStoryboardy-KVO-KVC
//
//  Created by Adam Wallraff on 11/17/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import "ViewController.h"
#import "Counter.h"

static void *kvoContext = &kvoContext;

@interface ViewController ()

@property(strong, nonatomic) Counter *counter;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.counter = [[Counter alloc]init];
    
    self.counter.count = 100;
    
    
}



- (IBAction)incrementPressed:(id)sender {

    [self.counter incrementCounter];

}



-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self addObserver:self forKeyPath:@"self.counter.count" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:&kvoContext];
}


-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    [self removeObserver:self forKeyPath:@"self.counter.count"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    
    if(context == kvoContext){
        
        NSLog(@"%ld", self.counter.count);
        
        if(self.counter.count == 110){
            NSLog(@"110! WHAA!");
        }
    } else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
    
}


+(BOOL)automaticallyNotifiesObserversOfCounter{
    return NO;
}


@end
